# /home/dyros/IsaacLab/source/isaaclab_tasks/isaaclab_tasks/manager_based/manipulation/dexsuite/config/hdr_dg5f/dexsuite_hdr_dg5f_env_cfg.py
# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from isaaclab_assets.robots import HDR_DG5F_CFG

from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensorCfg
from isaaclab.utils import configclass

from ... import dexsuite_env_cfg as dexsuite
from ... import mdp

# ====== HDR20 DG5F 설정 ======
# 손바닥 링크 (물체 조작의 기준 프레임)
PALM_LINK_NAME = "rl_dg_mount"

# DG5F 손가락 팁 링크 매핑 (5개 손가락 모두 사용)
# Allegro 스타일 키를 유지하되, 5번째 손가락 추가
DG5F_FINGERTIP_LINKS = {
    "thumb_link_3": "rl_dg_1_tip",     # 엄지
    "index_link_3": "rl_dg_2_tip",     # 검지
    "middle_link_3": "rl_dg_3_tip",    # 중지
    "ring_link_3": "rl_dg_4_tip",      # 약지
    "pinky_link_3": "rl_dg_5_tip",     # 새끼 (DG5F 추가 손가락)
}

# ContactSensor 이름 리스트
CONTACT_SENSOR_NAMES = [f"{link}_object_s" for link in DG5F_FINGERTIP_LINKS.keys()]
# =============================================

# @configclass
# class HdrDg5fRelJointPosActionCfg:
#     """HDR20 + DG5F 액션 설정 (20 DOF: 6 arm + 20 hand)"""
#     action = mdp.RelativeJointPositionActionCfg(
#         asset_name="robot",
#         # HDR20 arm: j1~j6 (6 DOF)
#         # DG5F hand: rj_dg_1_1 ~ rj_dg_5_4 (5 fingers * 4 joints = 20 DOF)
#         joint_names=[r"j[1-6]", r"rj_dg_.*"],
#         scale=0.1,
#     )

@configclass
class HdrDg5fRelJointPosActionCfg:
    action = mdp.RelativeJointPositionActionCfg(asset_name="robot", joint_names=[".*"], scale=0.1)



@configclass
class HdrDg5fReorientRewardCfg(dexsuite.RewardsCfg):
    """Reorient 태스크용 리워드 (손가락 접촉 추가)"""
    good_finger_contact = RewTerm(
        func=mdp.contacts,
        weight=0.5,
        params={"threshold": 1.0},
    )

@configclass
class HdrDg5fMixinCfg:
    rewards: HdrDg5fReorientRewardCfg = HdrDg5fReorientRewardCfg()
    actions: HdrDg5fRelJointPosActionCfg = HdrDg5fRelJointPosActionCfg()

    def __post_init__(self):
        super().__post_init__()

        # ===== Robot 설정 =====
        robot_cfg = HDR_DG5F_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        robot_cfg.spawn.activate_contact_sensors = True
        self.scene.robot = robot_cfg

        # ===== Commands 설정 =====
        self.commands.object_pose.body_name = PALM_LINK_NAME
        
        # ===== Events 설정 =====
        self.events.reset_robot_wrist_joint = None  # Kuka용 제거

        # ===== 환경 배치 (Lift/Reorient 공통) =====
        self.scene.env_spacing = 3.0
        self.scene.table.init_state.pos = (0.8, 0.0, 0.235)
        self.scene.object.init_state.pos = (0.85, 0.0, 0.35)
        
        # 목표 범위 (절대 좌표)
        self.commands.object_pose.ranges.pos_x = (0.85, 1.15)
        self.commands.object_pose.ranges.pos_y = (-0.15, 0.15)
        self.commands.object_pose.ranges.pos_z = (0.50, 0.80)
        self.commands.object_pose.debug_vis = True
        
        # 리셋 범위 (상대 오프셋)
        self.events.reset_object.params["pose_range"]["x"] = (-0.15, 0.15)
        self.events.reset_object.params["pose_range"]["y"] = (-0.15, 0.15)
        self.events.reset_object.params["pose_range"]["z"] = (-0.05, 0.15)

        # terminate 조건 변경 
        self.terminations.object_out_of_bound.params["in_bound_range"] = {
            "x": (-0.5, 2.5),   # ← 양수 x 방향 허용!
            "y": (-2.5, 2.5),
            "z": (-0.1, 2.5)
        }
        # self.observations.policy.object_pos_b = ObsTerm(func=mdp.object_pos_b, ...)

        # ===== ContactSensor 등록 (5개 손가락) =====
        for allegro_link, dg5f_tip in DG5F_FINGERTIP_LINKS.items():
            sensor_name = f"{allegro_link}_object_s"
            finger_num = dg5f_tip.split("_")[2]  # "rl_dg_1_tip" → "1"
            setattr(
                self.scene,
                sensor_name,
                ContactSensorCfg(
                    prim_path=f"{{ENV_REGEX_NS}}/Robot/hdr20_17/dg5f_right/rl_dg_{finger_num}_4",
                    filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
                    history_length=1,
                ),
            )

        # ===== Observations 설정 =====
        self.observations.proprio.contact = ObsTerm(
            func=mdp.fingers_contact_force_b,
            params={"contact_sensor_names": CONTACT_SENSOR_NAMES},
            clip=(-20.0, 20.0),
        )
        
        # 🔥 _4 사용 (rigid body)
        self.observations.proprio.hand_tips_state_b.params["body_asset_cfg"].body_names = [
            PALM_LINK_NAME, 
            "rl_dg_.*_4"  # ← 정규식으로 모든 _4 body
        ]


        # ===== Rewards 설정 =====
        # 🔥 _4 사용
        self.rewards.fingers_to_object.params["asset_cfg"] = SceneEntityCfg(
            "robot", 
            body_names=[PALM_LINK_NAME, "rl_dg_.*_4"]  # ← 정규식
        )

# ===== Reorient 환경 (회전 + 위치) =====
@configclass
class DexsuiteHdrDg5fReorientEnvCfg(HdrDg5fMixinCfg, dexsuite.DexsuiteReorientEnvCfg):
    pass


@configclass
class DexsuiteHdrDg5fReorientEnvCfg_PLAY(HdrDg5fMixinCfg, dexsuite.DexsuiteReorientEnvCfg_PLAY):
    pass


# ===== Lift 환경 (위치만) =====
@configclass
class DexsuiteHdrDg5fLiftEnvCfg(HdrDg5fMixinCfg, dexsuite.DexsuiteLiftEnvCfg):
    pass


@configclass
class DexsuiteHdrDg5fLiftEnvCfg_PLAY(HdrDg5fMixinCfg, dexsuite.DexsuiteLiftEnvCfg_PLAY):
    pass


# =========================== 기존 실행 코드= (LiftMixinCfg이용) ==================
# @configclass
# class HdrDg5fLiftMixinCfg:
#     """Lift 태스크 전용 Mixin"""
#     actions: HdrDg5fRelJointPosActionCfg = HdrDg5fRelJointPosActionCfg()

#     def __post_init__(self):
#         super().__post_init__()

#         robot_cfg = HDR_DG5F_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
#         robot_cfg.spawn.activate_contact_sensors = True  # ← 이 줄 추가!
#         self.scene.robot = robot_cfg       

#         self.commands.object_pose.body_name = PALM_LINK_NAME
#         self.events.reset_robot_wrist_joint = None
        
#         # ===== HDR20에 맞게 환경 재배치 =====

#         # =============== 여기부터 배치/크기/범위 튜닝 ===============

#         # # 0) env 간격 넓히기
#         # self.scene.env_spacing = 6.0  # 필요하면 7~8까지도 OK

#         # # 1) 테이블 크기/위치 (Y로 더 멀리, 길이는 좀 줄임)
#         # self.scene.table.spawn = self.scene.table.spawn.replace(
#         #     size=(0.80, 1.00, 0.04),   # (X, Y, Z) 길이(m) — 기존 1.5→1.0
#         #     # visible=True               # 색 확인하고 싶으면 True
#         # )
#         # self.scene.table.init_state = self.scene.table.init_state.replace(
#         #     pos=(0.0, 0.95, 0.235)     # 로봇 기준 Y≈0.95m 전방
#         # )

#         # # 2) 물체 초기 위치 (테이블 위쪽 근처)
#         # self.scene.object.init_state = self.scene.object.init_state.replace(
#         #     pos=(0.0, 1.00, 0.35)
#         # )

#         # # 3) 리셋 시 물체 위치 범위(= 네가 본 "respawn" 위치)
#         # #    '절대값' 샘플이 아니라 각 env 원점(=로봇 베이스) 기준 로컬 범위로 이해하면 편함.
#         # self.events.reset_object.params["pose_range"] = {
#         #     "x":    [-0.15, 0.15],
#         #     "y":    [ 0.90, 1.10],   # 로봇 정면 근처에 떨어지도록
#         #     "z":    [ 0.32, 0.48],   # 테이블 위 살짝
#         #     "roll": [-0.3, 0.3],
#         #     "pitch":[-0.3, 0.3],
#         #     "yaw":  [-3.14, 3.14],
#         # }

#         # # 4) 목표 포즈 샘플 범위(학습용 커맨드)
#         # #    obj 명령도 로봇 베이스 기준 범위. 테이블 위 근처로 좁혀줌.
#         # self.commands.object_pose.ranges = self.commands.object_pose.ranges.replace(
#         #     pos_x=(-0.20, 0.20),
#         #     pos_y=( 0.90, 1.10),
#         #     pos_z=( 0.55, 0.90),
#         #     roll =(-3.14, 3.14),
#         #     pitch=(-3.14, 3.14),
#         #     yaw  =( 0.0,  0.0),   # Lift는 yaw 고정이면 편함. 필요 시 풀어도 OK
#         # )

#         # ==========================================================

#         # 0) 환경 복제 간격을 늘려서 팔끼리도 안 부딪히게
#         self.scene.env_spacing = 4.0      # 기존 3 → 5 (필요하면 6~7로 더 키워도 OK)
        
#         # 1) 테이블 크기/위치: 로봇 앞(y)으로 밀고, y-길이는 짧게
#         # self.scene.table.spawn.size = (0.8, 0.9, 0.04)
#         # 테이블: 로봇 정면 (y축)
#         #self.scene.table.init_state.pos = (0.0, 1.2, 0.235)
#         self.scene.table.init_state.pos = (1.0, 0.0, 0.235)

#         # 물체: 테이블 위
#         self.scene.object.init_state.pos = (1.08, 0.0, 0.35) #0.0, -1.08, 0.35)
        
#         # 목표 범위 조정
#         self.commands.object_pose.ranges.pos_x = (0.75, 0.95)
#         self.commands.object_pose.ranges.pos_y = (-0.25, 0.25)
#         #self.commands.object_pose.ranges.pos_y = (-0.95, -0.75)
#         self.commands.object_pose.ranges.pos_z = (0.55, 0.95)
#         # 목표 시각화
#         self.commands.object_pose.debug_vis = True        

#         # 물체 리셋 위치도 조정
#         self.events.reset_object.params["pose_range"]["x"] = (-0.20, 0.20)
#         self.events.reset_object.params["pose_range"]["y"] = (-0.20, 0.20)        
#         #self.events.reset_object.params["pose_range"]["y"] = (0.80, 1.10)
#         # self.events.reset_object.params["pose_range"]["z"] = (0.30, 0.50)

#         # =====================================


#         # ContactSensor 등록 (Reorient와 동일)
#         for allegro_link, dg5f_tip in DG5F_FINGERTIP_LINKS.items():
#             sensor_name = f"{allegro_link}_object_s"
#             finger_num = dg5f_tip.split("_")[2]  # "rl_dg_1_tip" -> "1"
#             setattr(
#                 self.scene,
#                 sensor_name,
#                 ContactSensorCfg(
#                     prim_path=f"{{ENV_REGEX_NS}}/Robot/hdr20_17/dg5f_right/rl_dg_{finger_num}_4",
#                     filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
#                     history_length=1,
#                 ),
#             )
        
#         self.observations.proprio.contact = ObsTerm(
#             func=mdp.fingers_contact_force_b,
#             params={"contact_sensor_names": CONTACT_SENSOR_NAMES},
#             clip=(-20.0, 20.0),
#         )

# # ===== Reorient 환경 (회전 + 위치) =====
# @configclass
# class DexsuiteHdrDg5fReorientEnvCfg(HdrDg5fReorientMixinCfg, dexsuite.DexsuiteReorientEnvCfg):
#     pass


# @configclass
# class DexsuiteHdrDg5fReorientEnvCfg_PLAY(HdrDg5fReorientMixinCfg, dexsuite.DexsuiteReorientEnvCfg_PLAY):
#     pass


# # ===== Lift 환경 (위치만) =====
# @configclass
# class DexsuiteHdrDg5fLiftEnvCfg(HdrDg5fLiftMixinCfg, dexsuite.DexsuiteLiftEnvCfg):
#     pass


# @configclass
# class DexsuiteHdrDg5fLiftEnvCfg_PLAY(HdrDg5fLiftMixinCfg, dexsuite.DexsuiteLiftEnvCfg_PLAY):
#     pass